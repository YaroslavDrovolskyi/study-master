#include <iostream>
#include <limits>
#include <sstream>
#include <vector>

// Task: Згенерувати перші прості числа менше 10000
// Виконав: Дровольський Ярослав, ПЗС-1

long long int tryParse(const std::string& input);
long long int sqr(long long int x);
std::vector<long long int> generateFirstPrimeNumbersLessThan(long long int limit);

int main(int argc, char* argv[]) {
    std::string input;
    long long int inputNumber;

    bool inputSuccess = false;
    while(!inputSuccess) {
        std::cout << "Enter limit (integer number), to find all primes less than it: ";
        std::getline(std::cin, input);

        try {
            inputNumber = tryParse(input);
            inputSuccess = true;
        }
        catch(const std::invalid_argument& ex) {
            std::cout << "limit must be a valid integer number." << std::endl << std::endl;
        }
        catch(const std::out_of_range& ex) {
            std::cout << "limit must be from 1 to 3 037 000 499." << std::endl << std::endl;
        }
    }

    std::cout << "You entered: " << inputNumber << std::endl;

    generateFirstPrimeNumbersLessThan(inputNumber);

    std::cout << "Press ENTER To Exit...";
    std::cin.get();
    return 0;
}


long long int tryParse(const std::string& input) {
    long long int result = std::stoll(input); // https://en.cppreference.com/w/cpp/string/basic_string/stol
    long long int maxSqrt = 3037000499;

    if(result <= 0 || result > maxSqrt) {
        throw std::out_of_range("Input number must be from 1 to 3037000499");
    }

    return result;
}


/**
 * Generates array of first prime numbers, less than given limit.
 * Also prints that numbers gradually, as they are found
 * @returns generated array
 */
std::vector<long long int> generateFirstPrimeNumbersLessThan(long long int limit) {
    if(limit <= 0) {
        throw std::invalid_argument("ERROR: limit must be > 0");
    }

    if(limit <= 2) {
        std::cout << "There are no prime numbers less than " << limit << std::endl;
        return {};
    }


    long long int k;
    bool prim;
    std::vector<long long int> primeNumbers; // p
    std::vector<long long int> V; // V

    std::cout << "First prime numbers, less than " << limit << ":" << std::endl;

    primeNumbers.push_back(2); // p[1]:=2
    std::cout << "1)" << "\t" << primeNumbers.back() << std::endl;

    long long int x = 1; // candidate to be prime number
    long long int lim = 1;
    long long int kvadrat = 4; // is p^2, sqr of last generated prime number

    // instead of for i:=2...n, because we need not first n, but first that < limit
    while (x < limit) {
        do {
            x += 2;
            if(kvadrat <= x) {
                V.push_back(kvadrat); // instead of V[lim-1] = kvadrat;
                lim++; // lim is size(V)+1
                kvadrat = sqr(primeNumbers[lim-1]);
            }

            k = 2;
            prim = true;
            while(prim && (k < lim)) {
                if(V[k-1] < x) {
                    V[k-1] += primeNumbers[k-1];
                }
                prim = (x != V[k-1]);
                k++;
            }
        }
        while(!prim);
        // there, x is prime

        // need to check because on last iteration of loop, x is always >= limit
        if(x < limit) {
            primeNumbers.push_back(x);
            std::cout << primeNumbers.size() << ")\t" << x << std::endl;
        }
    }

    return primeNumbers;
}

/**
 *
 * @return square of x
 */
long long int sqr(long long int x) {
    return x * x;
}
